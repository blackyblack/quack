#!/bin/sh
java -cp quack.jar:lib/*:conf blackyblack.Application
